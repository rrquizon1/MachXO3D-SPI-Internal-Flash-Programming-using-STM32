// data.h
#ifndef FEATURE_ROW_H
#define FEATURE_ROW_H


extern unsigned char feature_row[];  // Declaration of the array
extern unsigned char feature_bits[];  // Declaration of the array

#endif // FASTCONFIG_DATA_H

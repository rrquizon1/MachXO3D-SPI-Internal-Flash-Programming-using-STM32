// data.h
#ifndef SPI_DATA_H
#define SPI_DATA_H

extern const int g_iDataSize;  // Declaration of the integer
extern const unsigned char g_pucDataArray_golden[];  // Declaration of the array
extern unsigned char usercode1[]; 

#endif // FASTCONFIG_DATA_H

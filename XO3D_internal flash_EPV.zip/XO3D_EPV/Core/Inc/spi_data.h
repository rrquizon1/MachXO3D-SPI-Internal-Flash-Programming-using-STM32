// data.h
#ifndef SPI_DATA_GOLDEN_H
#define SPI_DATA_GOLDEN_H

extern const int g_iDataSize;  // Declaration of the integer
extern const unsigned char g_pucDataArray[];  // Declaration of the array
extern const unsigned char usercode0[];

#endif // FASTCONFIG_DATA_H
